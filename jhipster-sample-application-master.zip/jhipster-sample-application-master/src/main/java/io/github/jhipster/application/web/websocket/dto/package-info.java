/**
 * Data Access Objects used by WebSocket services.
 */
package io.github.jhipster.application.web.websocket.dto;
