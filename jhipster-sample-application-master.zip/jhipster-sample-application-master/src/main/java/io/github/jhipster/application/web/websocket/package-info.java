/**
 * WebSocket services, using Spring Websocket.
 */
package io.github.jhipster.application.web.websocket;
