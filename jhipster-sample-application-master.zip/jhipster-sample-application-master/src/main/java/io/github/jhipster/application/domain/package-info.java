/**
 * JPA domain objects.
 */
package io.github.jhipster.application.domain;
