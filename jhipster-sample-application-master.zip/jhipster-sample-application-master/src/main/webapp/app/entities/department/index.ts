export * from './department.service';
export * from './department-update.component';
export * from './department-delete-dialog.component';
export * from './department-detail.component';
export * from './department.component';
export * from './department.route';
